import React, { useState } from 'react';
import { Bug } from './types';
import BugList from './components/BugList';
import BugForm from './components/BugForm';
import { Bug as BugIcon, Plus, X } from 'lucide-react';

function App() {
  const [bugs, setBugs] = useState<Bug[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [selectedBug, setSelectedBug] = useState<Bug | null>(null);

  const handleCreateBug = (newBug: Omit<Bug, 'id' | 'createdAt' | 'updatedAt'>) => {
    const bug: Bug = {
      ...newBug,
      id: Date.now().toString(),
      createdAt: new Date(),
      updatedAt: new Date()
    };
    setBugs([...bugs, bug]);
    setShowForm(false);
  };

  const handleStatusChange = (bugId: string, newStatus: Bug['status']) => {
    setBugs(bugs.map(bug => 
      bug.id === bugId 
        ? { ...bug, status: newStatus, updatedAt: new Date() }
        : bug
    ));
    setSelectedBug(null);
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <BugIcon className="h-8 w-8 text-indigo-600" />
              <h1 className="ml-3 text-3xl font-bold text-gray-900">Bug Tracker</h1>
            </div>
            <button
              onClick={() => setShowForm(true)}
              className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            >
              <Plus className="h-5 w-5 mr-2" />
              New Bug
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
          <div className="space-y-4">
            <h2 className="text-lg font-semibold text-gray-900">Open</h2>
            <BugList
              bugs={bugs.filter(bug => bug.status === 'open')}
              onBugSelect={setSelectedBug}
            />
          </div>
          <div className="space-y-4">
            <h2 className="text-lg font-semibold text-gray-900">In Progress</h2>
            <BugList
              bugs={bugs.filter(bug => bug.status === 'in-progress')}
              onBugSelect={setSelectedBug}
            />
          </div>
          <div className="space-y-4">
            <h2 className="text-lg font-semibold text-gray-900">Resolved</h2>
            <BugList
              bugs={bugs.filter(bug => bug.status === 'resolved')}
              onBugSelect={setSelectedBug}
            />
          </div>
        </div>
      </main>

      {/* New Bug Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">Create New Bug</h2>
              <button onClick={() => setShowForm(false)} className="text-gray-400 hover:text-gray-500">
                <X className="h-6 w-6" />
              </button>
            </div>
            <BugForm onSubmit={handleCreateBug} />
          </div>
        </div>
      )}

      {/* Bug Details Modal */}
      {selectedBug && (
        <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg p-6 max-w-md w-full">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">{selectedBug.title}</h2>
              <button onClick={() => setSelectedBug(null)} className="text-gray-400 hover:text-gray-500">
                <X className="h-6 w-6" />
              </button>
            </div>
            <div className="space-y-4">
              <p className="text-gray-600">{selectedBug.description}</p>
              <div className="flex justify-between text-sm text-gray-500">
                <span>Assigned to: {selectedBug.assignee}</span>
                <span>Priority: {selectedBug.priority}</span>
              </div>
              <div className="flex space-x-2">
                <button
                  onClick={() => handleStatusChange(selectedBug.id, 'open')}
                  className="flex-1 py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-red-600 hover:bg-red-700"
                >
                  Open
                </button>
                <button
                  onClick={() => handleStatusChange(selectedBug.id, 'in-progress')}
                  className="flex-1 py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-yellow-600 hover:bg-yellow-700"
                >
                  In Progress
                </button>
                <button
                  onClick={() => handleStatusChange(selectedBug.id, 'resolved')}
                  className="flex-1 py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700"
                >
                  Resolved
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;