import React from 'react';
import { Bug } from '../types';
import { AlertCircle, CheckCircle2, Clock } from 'lucide-react';

interface BugListProps {
  bugs: Bug[];
  onBugSelect: (bug: Bug) => void;
}

const statusIcons = {
  'open': <AlertCircle className="text-red-500" />,
  'in-progress': <Clock className="text-yellow-500" />,
  'resolved': <CheckCircle2 className="text-green-500" />
};

const priorityColors = {
  'low': 'bg-blue-100 text-blue-800',
  'medium': 'bg-yellow-100 text-yellow-800',
  'high': 'bg-red-100 text-red-800'
};

export default function BugList({ bugs, onBugSelect }: BugListProps) {
  return (
    <div className="space-y-4">
      {bugs.map((bug) => (
        <div
          key={bug.id}
          onClick={() => onBugSelect(bug)}
          className="bg-white p-4 rounded-lg shadow-sm hover:shadow-md transition-shadow cursor-pointer"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              {statusIcons[bug.status]}
              <h3 className="font-medium">{bug.title}</h3>
            </div>
            <span className={`px-2 py-1 rounded-full text-xs font-medium ${priorityColors[bug.priority]}`}>
              {bug.priority}
            </span>
          </div>
          <p className="mt-2 text-gray-600 text-sm line-clamp-2">{bug.description}</p>
          <div className="mt-3 flex items-center justify-between text-sm text-gray-500">
            <span>Assigned to: {bug.assignee}</span>
            <span>{new Date(bug.updatedAt).toLocaleDateString()}</span>
          </div>
        </div>
      ))}
    </div>
  );
}